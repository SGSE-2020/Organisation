package main;

import auth.AuthGrpc;
import auth.AuthOuterClass;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

import java.io.IOException;
import java.util.logging.Logger;

public class AuthServer {

	private static final Logger logger = Logger.getLogger(AuthServer.class.getName());

	private Server server;
	private int port;

	public AuthServer(int port) {
		this.port = port;
	}

	private void start() throws IOException	{
		server = ServerBuilder.forPort(port)
				.addService(new AuthImpl())
//				.intercept(new JwtServerInterceptor())  // add the JwtServerInterceptor
				.build()
				.start();
		logger.info("Server started, listening on " + port);
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				System.err.println("*** shutting down gRPC server since JVM is shutting down");
				AuthServer.this.stop();
				System.err.println("*** server shut down");
			}
		});
	}

	private void stop() {
		if (server != null) {
			server.shutdown();
		}
	}

	private void blockUntilShutdown() throws InterruptedException {
		if (server != null) {
			server.awaitTermination();
		}
	}

	public static void main(String[] args) throws IOException, InterruptedException {
		int port = 50051; // default
		if (args.length > 0) {
			port = Integer.parseInt(args[0]);
		}

		final AuthServer server = new AuthServer(port);
		server.start();
		server.blockUntilShutdown();
	}

	static class AuthImpl extends AuthGrpc.AuthImplBase {
		@Override
		public void login(AuthOuterClass.LoginRequest request, StreamObserver<AuthOuterClass.LoginResponse> responseObserver) {
			AuthOuterClass.LoginResponse reply = AuthOuterClass.LoginResponse.newBuilder().setToken("Fake Token").build();
			responseObserver.onNext(reply);
			responseObserver.onCompleted();
		}
	}
}
